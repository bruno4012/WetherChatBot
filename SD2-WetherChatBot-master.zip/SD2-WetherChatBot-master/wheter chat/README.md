# Project:
The chatBot project is a group project which was assigned to the students in the Software Development 2 module from the second year of Computing science at Griffith College Dublin. The project has specific requirements and was with a duration of 10 weeks.
## Group participants:
Bruno Martins - 3014022 and Silvia Nikolova - 3019233
Team name: Mark-e
## Introduction
During the last 10 weeks, we were asked to develop a chatBot with specific requirements and one main reason to provide users with cloths recommendation depending of the visit country and the user input.
# How to use it:
The chatBot is developed by using mostly JavaScript language and also with the help of HTML and CSS languages which the team used mostly to provide the current chatBot design.
The chatBot is really easy and straight follow to be used. The chatBot folder contains 3 main JavaScript files, one HTML and one CSS files. The JavaScript files are providing the chatBot behaviour and implementation.
The fetch.js file is used to make the connection with Open Weather API and is one of the main files without which the chatBot will not be able to work using the weather API.
## What you will need to use the code?
As the chatBot is built by mostly using JavaScript this make it really easy to be used. The only thing you will need to do is to open the HTML file on your Browser and of course start you conversation.
## What is the chatBot can answer and do?
The chatBot is able to make a conversation with the user based on simple question and answers such as: "Hello, How are you?, Thank you!..., etc.". The chatBot can answer appropriate to do the user input and is also able to give recommendation based on the current weather for the specific country.
